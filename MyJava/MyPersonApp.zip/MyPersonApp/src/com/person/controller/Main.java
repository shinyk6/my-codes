package com.person.controller;

public class Main { //진입점

	public static void main(String[] args) {
		
		new PersonController().run();

	}

}
