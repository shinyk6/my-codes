package com.sec04.Decorator;
public interface Notifier {
    void send();
}
