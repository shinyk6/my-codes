package com.sec03.Composite;
public interface Component {
    void show();
}
