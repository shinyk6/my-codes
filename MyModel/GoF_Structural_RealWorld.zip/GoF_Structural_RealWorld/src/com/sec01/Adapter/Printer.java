package com.sec01.Adapter;
public interface Printer {
    void print(String message);
}
