package com.sec01.Adapter;
public class LegacyPrinter {
    public void oldPrint(String text) {
        System.out.println("Legacy: " + text);
    }
}
