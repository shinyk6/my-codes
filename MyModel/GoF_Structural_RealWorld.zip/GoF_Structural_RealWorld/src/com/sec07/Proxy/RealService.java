package com.sec07.Proxy;
public class RealService {
    public void request() {
        System.out.println("RealService is handling the request.");
    }
}
