package com.sec07.Proxy;
public class TestProxy {
    public static void main(String[] args) {
        ServiceProxy proxy = new ServiceProxy();
        proxy.request();
    }
}
