package com.sec05.Facade;
public class Lights {
    public void turnOn() { System.out.println("Lights on"); }
}
