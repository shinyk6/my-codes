package com.sec05.Facade;
public class Engine {
    public void start() { System.out.println("Engine started"); }
}
