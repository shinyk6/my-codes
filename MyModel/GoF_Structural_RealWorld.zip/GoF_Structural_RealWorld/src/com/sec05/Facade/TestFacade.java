package com.sec05.Facade;
public class TestFacade {
    public static void main(String[] args) {
        CarFacade car = new CarFacade();
        car.startCar();
    }
}
