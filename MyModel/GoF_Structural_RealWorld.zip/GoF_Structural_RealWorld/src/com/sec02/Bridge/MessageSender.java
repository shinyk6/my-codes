package com.sec02.Bridge;
public interface MessageSender {
    void send(String message);
}
