package com.sec03.AbstractFactory;

public interface GUIFactory {
    Button createButton();
}
