package com.sec03.AbstractFactory;

public interface Button {
    void render();
}
