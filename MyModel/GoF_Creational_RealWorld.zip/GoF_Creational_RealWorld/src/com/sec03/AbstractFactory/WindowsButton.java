package com.sec03.AbstractFactory;

public class WindowsButton implements Button {
    public void render() {
        System.out.println("Rendering Windows Button");
    }
}
