package com.sec02.FactoryMethod;

public interface Document {
    void open();
}
